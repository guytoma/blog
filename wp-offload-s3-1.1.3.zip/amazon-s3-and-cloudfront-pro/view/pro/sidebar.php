<div class="as3cf-sidebar pro">
	<?php do_action( 'as3cfpro_sidebar' ); ?>
</div>
